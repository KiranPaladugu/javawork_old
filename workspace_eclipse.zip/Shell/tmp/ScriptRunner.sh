
echo "changing Shell"
csh
echo "Changed Shell to CSH"
cd /cygdrive/c/workspace_eclipse/Shell/tmp/
./MakeAgentTar