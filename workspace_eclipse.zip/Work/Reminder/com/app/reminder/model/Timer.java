package com.app.reminder.model;


public interface Timer {
	public long start();
	public long stop();
	public long getMean();
}
