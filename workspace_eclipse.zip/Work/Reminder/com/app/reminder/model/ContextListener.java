package com.app.reminder.model;

public interface ContextListener {
	
	public void ContextChanged(ContextEvent evnet);

}
