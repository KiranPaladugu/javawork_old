package com.app.reminder.model;

public interface Action {
	public String getName();
	public Object getObject();
}
