package com.app.reminder.gui;

public class GUI {
	public void start(){
		
	}
}
