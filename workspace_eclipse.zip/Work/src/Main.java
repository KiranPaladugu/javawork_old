import com.tcs.berReader.BerReader;


public class Main {

	public static void main(final String[] args) {
		new BerReader().load();
		System.exit(0);
	}
}
