
/**
 * File Name : <tt>CharPrinter</tt>
 * @author ekirpal
 *
 */
public class CharPrinter {
	
	/** This is main method <TT> Main </TT>
	 * 
	 * @param args
	 * @return void
	 * @see Object
	 */
	public static void main(String args[]){
		for(int index =0; index<256 ;index++){
			System.out.println("Char [ ].. for "+index+" is :"+(char)index);			
		}
	}
}
