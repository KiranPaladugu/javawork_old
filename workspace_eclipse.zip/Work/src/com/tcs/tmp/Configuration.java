package com.tcs.tmp;

public class Configuration {

}
