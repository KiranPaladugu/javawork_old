package com.tcs.log.fequency;

public class GUI {
	public static int instances = 0;
	
	public static void start(){
		
	}
}
