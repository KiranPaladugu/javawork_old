package com.framework.reg;


public class RegisterException extends Exception {
	private static final long serialVersionUID = 8933086285987891239L;

	public RegisterException() {
		super();
	}
	public RegisterException(String cause){
		super(cause);
	}
}
