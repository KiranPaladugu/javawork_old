import com.tcs.tmp.UserInterface;


public class GuiRunner {
	public static void main(String args[]){
		new UserInterface().init();
	}
}
