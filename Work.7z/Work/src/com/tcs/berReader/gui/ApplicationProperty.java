package com.tcs.berReader.gui;

public class ApplicationProperty {
	
}
