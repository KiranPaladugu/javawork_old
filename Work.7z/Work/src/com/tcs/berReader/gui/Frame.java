package com.tcs.berReader.gui;



public class Frame {
	public void init(){
	}
}
