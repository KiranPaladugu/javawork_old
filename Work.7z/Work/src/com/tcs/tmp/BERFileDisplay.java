package com.tcs.tmp;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JDialog;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

import com.framework.reg.Register;
import com.marconi.fusion.X36.X36CardInformation;
import com.marconi.fusion.X36.X36PortInformation;
import com.marconi.fusion.X36.X36SetOfCardInformation;
import com.marconi.fusion.X36.X36SetOfPortInformation;
import com.marconi.fusion.X36.X36SetOfShelfInformation;
import com.marconi.fusion.X36.X36ShelfInformation;
import com.tcs.berReader.BERFileData;
import com.tcs.tree.view.TreeNodeCard;
import com.tcs.tree.view.TreeNodePort;
import com.tcs.tree.view.TreeNodeShelf;
import com.tcs.tree.view.UserTreeNode;

public class BERFileDisplay {
	private BERFileData data;
	private JMenuItem displyObject;
	private JMenuItem getSpecificInfo;
	private JTree tree;

	public BERFileDisplay(BERFileData data) {
		this.data = data;
	}

	public void displayBer() {
		if (true) {
			treeView();
			return;
		}
	}

	public void treeView() {
		JDialog dialog = new JDialog(((UserInterface) Register.getObject(UserInterface.class)).getFrame());
		DefaultMutableTreeNode root = new DefaultMutableTreeNode("Root");
		DefaultMutableTreeNode node = new DefaultMutableTreeNode(data.getNodeConfig().getBody().getNetworkElement().getNeId());
		root.add(node);
		tree = new JTree(root);
		final JPopupMenu popup = initPopup();
		tree.add(popup);
		tree.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					popup.show(e.getComponent(), e.getX(), e.getY());
				}
			}

			@Override
			public void mousePressed(MouseEvent arg0) {

			}

			@Override
			public void mouseExited(MouseEvent arg0) {

			}

			@Override
			public void mouseEntered(MouseEvent arg0) {

			}

			@Override
			public void mouseClicked(MouseEvent arg0) {

			}
		});
		dialog.setModal(true);
		dialog.setLayout(new GridLayout(1, 1));
		JScrollPane scroll = new JScrollPane(tree);
		dialog.add(scroll);
		NodeConfigQueryHandler ncq = new NodeConfigQueryHandler(data);
		X36SetOfShelfInformation shelfs = ncq.getShelfInfo();
		for (X36ShelfInformation shelf : shelfs) {
			TreeNodeShelf s = new TreeNodeShelf(shelf);
			DefaultMutableTreeNode sh = new DefaultMutableTreeNode(s);
			node.add(sh);
			X36SetOfCardInformation cards = shelf.getCards();
			for (X36CardInformation card : cards) {
				TreeNodeCard c = new TreeNodeCard(card);
				DefaultMutableTreeNode ca = new DefaultMutableTreeNode(c);
				sh.add(ca);
				X36SetOfPortInformation ports = card.getPorts();
				for (X36PortInformation port : ports) {
					TreeNodePort p = new TreeNodePort(port);
					DefaultMutableTreeNode po = new DefaultMutableTreeNode(p);
					ca.add(po);
				}
			}
		}
		dialog.setBounds(DisplayDialog.setDialogLocation(300, 600));
		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		dialog.setVisible(true);

	}

	private JPopupMenu initPopup() {
		JPopupMenu popup = new JPopupMenu();
		displyObject = new JMenuItem("displayObject");
		getSpecificInfo = new JMenuItem("getSpecificInfo");
		displyObject.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent ae) {
				TreePath path = tree.getSelectionPath();
				if (path != null) {
					Object object = tree.getSelectionPath().getLastPathComponent();
					if (object instanceof DefaultMutableTreeNode) {
						DefaultMutableTreeNode node = (DefaultMutableTreeNode) object;
						Object obj = node.getUserObject();
						if (obj instanceof UserTreeNode) {
							if (obj instanceof TreeNodePort) {
								DisplayDialog.dispalyMessage(((TreeNodePort) obj).getSyntax(),"PortInformation!");								
							} else if (obj instanceof TreeNodeCard) {
								DisplayDialog.dispalyMessage(((TreeNodeCard) obj).getSyntax(),"CardInformation!");
							} else if (obj instanceof TreeNodeShelf) {
								DisplayDialog.dispalyMessage(((TreeNodeShelf) obj).getSyntax(),"ShelfInformation!");
							}
						}
					}
				}
			}
		});
		getSpecificInfo.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				TreePath path = tree.getSelectionPath();
				if (path != null) {
					Object object = tree.getSelectionPath().getLastPathComponent();
					if (object instanceof DefaultMutableTreeNode) {
						DefaultMutableTreeNode node = (DefaultMutableTreeNode) object;
						Object obj = node.getUserObject();
						if (obj instanceof UserTreeNode) {
							if (obj instanceof TreeNodePort) {
								DisplayDialog.dispalyMessage(((TreeNodePort) obj).getSpecificInfo(),"PortInformation!");								
							} else if (obj instanceof TreeNodeCard) {
								DisplayDialog.dispalyMessage(((TreeNodeCard) obj).getSpecificInfo(),"CardInformation!");
							} else if (obj instanceof TreeNodeShelf) {
								DisplayDialog.dispalyMessage(((TreeNodeShelf) obj).getSpecificInfo(),"ShelfInformation!");
							}
						}
					}
				}
			}
		});
		popup.add(displyObject);
		popup.add(getSpecificInfo);
		return popup;
	}
}
