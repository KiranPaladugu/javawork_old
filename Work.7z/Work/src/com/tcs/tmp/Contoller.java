package com.tcs.tmp;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;

import com.framework.reg.Register;

public class Contoller extends JPanel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1763094037000706996L;
	private JPanel panel;
	private JButton addBer;
	private JButton addFolder;
	private JButton load;
	private UserOperations operations;
	//private LayoutMan layoutman = new LayoutMan();
	 
	
	public Contoller() {
		panel = this;
		operations = (UserOperations) Register.getObject(UserOperations.class);
		if(operations == null){
			operations = new UserOperations();
			Register.register(operations);
		}
		init();
	}
	public void init(){
		//panel.setLayout(null);
		addItems();
		panel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
	}
	private void addItems() {
		//layoutman.setX(10);
		//layoutman.setY(1);
		addBer= new JButton("AddBER");
		addBer.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				operations.openFileOperation();
			}
		});
		
		//addBer.setBounds(layoutman.getBounds(100, 25, LayoutMan.LAYOUTMAN_HORIZANTAL_ALIGN));
		addFolder = new JButton("AddFolder");
		addFolder.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				operations.openFolderOperation();
			}
		});
		//addFolder.setBounds(layoutman.getBounds(100, 25, LayoutMan.LAYOUTMAN_HORIZANTAL_ALIGN));
		load = new JButton("load");
		//load.setBounds(layoutman.getBounds(100, 25, LayoutMan.LAYOUTMAN_HORIZANTAL_ALIGN));
		
		
		panel.add(addBer);
		panel.add(addFolder);
		panel.add(load);
	}
}
