package com.tcs.tmp;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;

import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.framework.reg.Register;
import com.tcs.berReader.BERFileData;

public class BERListPane extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7322952642670934505L;
	private JList list;
	private JScrollPane scorll;
	private BerFileListModel model;
	private JPopupMenu popup;
	private JMenuItem load, delete, refresh, writetoTxt;

	public BERListPane() {
		Register.register(this);
		this.setLayout(new GridLayout(1, 1));
		init();
		add(scorll);
	}

	private void init() {
		list = new JList();
		scorll = new JScrollPane(list);
		model = new BerFileListModel();
		list.setModel(model);
		initPopup();
		list.add(popup);
		list.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				maybeShowPopup(e);

			}

			@Override
			public void mousePressed(MouseEvent e) {

			}

			@Override
			public void mouseExited(MouseEvent e) {

			}

			@Override
			public void mouseEntered(MouseEvent e) {

			}

			@Override
			public void mouseClicked(MouseEvent e) {

			}
		});

		list.addPropertyChangeListener(new PropertyChangeListener() {

			@Override
			public void propertyChange(PropertyChangeEvent arg0) {
				load();
			}
		});

		list.getModel().addListDataListener(new ListDataListener() {

			@Override
			public void intervalRemoved(ListDataEvent arg0) {

			}

			@Override
			public void intervalAdded(ListDataEvent arg0) {

			}

			@Override
			public void contentsChanged(ListDataEvent arg0) {

			}
		});

		list.addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent evt) {
				load();
			}
		});
	}

	private void load() {
		BerViewPane viewer = (BerViewPane) Register.getObject(BerViewPane.class);
		if (viewer != null) {
			try {
				if (list.getSelectedIndex() != -1) {
					BerFileListItem item = (BerFileListItem) list.getSelectedValue();
					viewer.displayBER(item.getValue());
				}
			} catch (Exception e) {
			}
		}
	}

	private void maybeShowPopup(MouseEvent e) {
		if (e.isPopupTrigger()) {
			popup.show(e.getComponent(), e.getX(), e.getY());
		}
	}

	private void initPopup() {
		popup = new JPopupMenu("Options.. !");
		load = new JMenuItem("ShowBerDetails..");
		load.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(list.getSelectedIndex()!=-1){
					BERFileData data = ((BerFileListItem)list.getSelectedValue()).getValue();
					BERFileDisplay display = new BERFileDisplay(data);
					display.displayBer();
					
				}
			}
		});
		delete = new JMenuItem("Delete..");
		refresh = new JMenuItem("Refresh..");
		writetoTxt = new JMenuItem("Write to text file..");

		popup.add(load);
		popup.add(delete);
		popup.add(refresh);
		popup.addSeparator();
		popup.add(writetoTxt);
	}

	public void addToList(File file, BERFileData data) {
		BerFileListItem item = new BerFileListItem(file, data);
		model.add(item);
	}

	public void addToList(BerFileListItem item) {
		model.add(item);
	}
	
	public BERFileData getSelectedItem(){
		return ((BerFileListItem)list.getSelectedValue()).getValue();
	}

}
