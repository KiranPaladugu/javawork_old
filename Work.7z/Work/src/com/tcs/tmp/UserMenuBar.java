package com.tcs.tmp;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import com.framework.reg.Register;

public class UserMenuBar extends JMenuBar{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6385684710034925470L;
	private JMenuBar menubar;
	private JMenu file,help,options,view,edit;
	private JMenuItem file_open,file_save,file_saveAs,file_exit;
	private UserOperations operations;
	
	public UserMenuBar() {
		init();
		operations = (UserOperations) Register.getObject(UserOperations.class);
		if(operations == null){
			operations = new UserOperations();
			Register.register(operations);
		}
	}
	
	public void init(){
		initMenu();
	}
	private void initMenu() {
		menubar = this;
		
		initFileMenu();
		initEditMenu();
		initViewMenu();
		initOptionsMenu();
		initHelpMenu();
		
		menubar.add(file);
		menubar.add(edit);
		menubar.add(view);
		menubar.add(options);
		menubar.add(help);
		menubar.setVisible(true);
	}
	private void initHelpMenu() {
		help = new JMenu("Help");
		
	}
	private void initOptionsMenu() {
		options = new JMenu("Options");
	}
	private void initViewMenu() {
		view = new JMenu("Options");
	}
	private void initEditMenu() {
		edit = new JMenu("Edit");
	}
	private void initFileMenu() {
		file = new JMenu("File");
		
		file_open = new JMenuItem("Open");
		file.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				operations.openFileOperation();
			}
		});
		file_save = new JMenuItem("Save");
		file_save.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				operations.saveFileOperation();
				
			}
		});
		file_saveAs = new JMenuItem("SaveAs");
		file_saveAs.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				operations.saveAsFileOperation();
				
			}
		});
		file_exit = new JMenuItem("Exit");
		file_exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				operations.applicationExit();
			}
		});
		
		file.add(file_open);
		file.addSeparator();
		file.add(file_save);
		file.add(file_saveAs);
		file.addSeparator();
		file.add(file_exit);
		
	}
	
	public String toString(){
		StringBuilder message=new StringBuilder("UserMenuBar");
		message.append("\n File:"+file);
		message.append("\n Edit:"+edit);
		message.append("\n view:"+view);
		message.append("\n Options:"+options);
		message.append("\n Help:"+help);
		return message.toString();
		
	}
}
