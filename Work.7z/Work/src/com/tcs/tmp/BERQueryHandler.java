package com.tcs.tmp;

public class BERQueryHandler {

}
