package com.tcs.tmp;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.UIManager;

import com.framework.reg.Register;
import com.framework.reg.RegisterException;

public class UserInterface {

	private JFrame frame;
	private UserOperations operations;
	private UserMenuBar menu;
	private UserToolbar toolbar;
	private Contoller control;
	private ResultPane result;
	private StatusPane status;
	private GridBagConstraints gc;

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public UserInterface() {
		Register.register(this);
		
		gc = new GridBagConstraints();
		gc.insets = new Insets(1, 1, 1, 1);
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		gc.fill = GridBagConstraints.BOTH;
		gc.gridwidth = GridBagConstraints.REMAINDER;
		
		operations = (UserOperations) Register.getObject(UserOperations.class);
		if (operations == null) {
			operations = new UserOperations();
			Register.register(operations);
		}
	}

	public void init() {
		initTheme();
		initFrame();
		initMenuBar();
		initToolbar();
		initController();
		initMiddle();
		initStatus();
		setFrameLocation();
		setVisibility();
	}

	private void initToolbar() {
		toolbar = (UserToolbar) Register.getObject(UserToolbar.class);
		if (toolbar == null) {
			toolbar = new UserToolbar();
			Register.register(toolbar);
		}

		gc.gridx = 0;
		gc.gridy = 0;
		gc.weightx = 1;
		gc.weighty = 0;
		gc.gridheight = 1;
		
		frame.add(toolbar, gc);
	}

	private void initController() {
		try {
			control = (Contoller) Register.getCheckedObject(Contoller.class);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.weightx = 1;
			gc.weighty = 0;			
			gc.gridheight = 1;

			frame.add(control, gc);
		} catch (RegisterException e) {
			e.printStackTrace();
		}
	}

	private void initMiddle() {
		try {
			result = (ResultPane) Register.getCheckedObject(ResultPane.class);

			gc.gridx = 0;
			gc.gridy = 2;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.gridheight = 15;

			frame.add(result, gc);
		} catch (RegisterException e) {
			e.printStackTrace();
		}
	}

	private void initStatus() {
		try {
			status = (StatusPane) Register.getCheckedObject(StatusPane.class);
			status.setBorder(BorderFactory.createLineBorder(Color.GRAY));

			gc.anchor = GridBagConstraints.LAST_LINE_START;
			gc.gridx = 0;
			gc.gridy = 17;
			gc.weightx = 1;
			gc.weighty = 0;
			gc.gridheight = GridBagConstraints.REMAINDER;

			frame.add(status);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void setFrameLocation() {
		int wid = 800;
		int het = 600;
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (dim.width - wid) / 2;
		int y = (dim.height - het) / 2;
		frame.setBounds(x, y, wid, het);
		frame.setSize(wid, het);
	}

	private void setVisibility() {
		frame.setSize(800, 600);
		frame.addWindowListener(new WindowListenerImpl());
		frame.setVisible(true);
	}

	private void initMenuBar() {
		menu = (UserMenuBar) Register.getObject(UserMenuBar.class);
		if (menu == null) {
			menu = new UserMenuBar();
			Register.register(menu);
		}
		frame.setJMenuBar(menu);
	}

	private void initTheme() {
		final String windowsTheme = "com.sun.java.swing.plaf.windows.WindowsLookAndFeel";
		try {
			UIManager.setLookAndFeel(windowsTheme);
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}

	private void initFrame() {
		frame = new JFrame("BER Reader :)");
		frame.setLayout(new GridBagLayout());
	}

	class WindowListenerImpl implements WindowListener {

		@Override
		public void windowActivated(WindowEvent e) {
		}

		@Override
		public void windowClosed(WindowEvent e) {
		}

		@Override
		public void windowClosing(WindowEvent e) {
			operations.applicationExit();
		}

		@Override
		public void windowDeactivated(WindowEvent e) {
		}

		@Override
		public void windowDeiconified(WindowEvent e) {
		}

		@Override
		public void windowIconified(WindowEvent e) {
		}

		@Override
		public void windowOpened(WindowEvent e) {
		}

	}
}
