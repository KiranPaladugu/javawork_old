package com.tcs.tmp;

import java.io.File;

import javax.swing.JFileChooser;

import com.framework.reg.Register;
import com.framework.reg.RegisterException;
import com.logService.Logger;
import com.tcs.berReader.BERFileData;
import com.tcs.berReader.BerReader;
import com.tcs.berReader.BerReader.BerFileFilter;

public class UserOperations {
	private BerFileListHandler handler;

	public UserOperations() {
		try {
			handler = (BerFileListHandler) Register.getCheckedObject(BerFileListHandler.class);
		} catch (RegisterException e) {
			e.printStackTrace();
		}
	}

	public void applicationExit() {
		exit();
	}

	public void openFileOperation() {
		final JFileChooser fileChooser = new JFileChooser();
		final BerFileFilter logFilter = new BerReader().new BerFileFilter();
		fileChooser.setFileFilter(logFilter);
		final int x = fileChooser.showDialog(null, "Open");
		File file = null;
		if (x == JFileChooser.APPROVE_OPTION) {
			file = fileChooser.getSelectedFile();
			openBERFile(file);
		}
	}

	/**
	 * @param file
	 */
	private void openBERFile(File file) {
		BERFileData data = handler.getBERData(file);
		BerFileListItem item = new BerFileListItem(file, data);
		addToBERList(item);
	}

	public void openFolderOperation() {
		final JFileChooser fileChooser = new JFileChooser();
		fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		final int x = fileChooser.showDialog(null, "Open");
		File file = null;
		if (x == JFileChooser.APPROVE_OPTION) {
			file = fileChooser.getSelectedFile();
			identifyBERs(file);
		}
	}

	private void identifyBERs(File file) {
		if (file.isDirectory()) {
			String parent = file.getParent();
			String[] files = file.list();
			for (String name : files) {
				File f = new File(parent + File.separator+file.getName()+File.separator + name);
				if (file.isDirectory()) {
					identifyBERs(f);
				} else {
					verifyAndLoadBER(file);
				}
			}
		} else {
			verifyAndLoadBER(file);
		}
	}

	private void verifyAndLoadBER(File file) {
		if (file != null) {
			if (file.getName().endsWith(".ber") || file.getName().endsWith(".BER")) {
				openBERFile(file);
			}
		}
	}

	private void addToBERList(BerFileListItem item) {
		BERListPane list = (BERListPane) Register.getObject(BERListPane.class);
		if (list != null) {
			list.addToList(item);
		}
	}

	public void saveFileOperation() {

	}

	public void saveAsFileOperation() {

	}

	private void exit() {
		Logger.closeLog();
		System.exit(0);
	}

}
