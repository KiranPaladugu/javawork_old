package com.tcs.tmp;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JPanel;

import com.framework.reg.Register;

public class ResultPane extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3304011900328306864L;
	private BERListPane listPane;
	private BerViewPane berView;
	private GridBagConstraints gc;
	public ResultPane() {
		Register.register(this);
		
		this.setLayout(new GridBagLayout());
		
		gc = new GridBagConstraints();
		gc.insets = new Insets(1, 1, 1, 1);
		gc.fill = GridBagConstraints.BOTH;
		gc.gridheight = GridBagConstraints.REMAINDER;
		
		init();
	}

	private void init() {		
		initLeft();
		initRight();
	}

	private void initLeft() {
		listPane = new BERListPane();
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		gc.gridx = 0;
		gc.gridy =0;
		gc.weightx =0.25;
		gc.weighty=1;
		gc.gridwidth=1;
		
		
		add(listPane,gc);
	}
	
	private void initRight() {
		berView = new BerViewPane(null);
		gc.weightx =1;
		gc.weighty=1;
		gc.gridx = 4;
		gc.gridy =0;
		gc.gridwidth=GridBagConstraints.REMAINDER;
		
		add(berView ,gc);
	}
	
}
