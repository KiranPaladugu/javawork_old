package com.tcs.tmp;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import com.logService.Logger;
import com.tcs.berReader.BERFileData;
import com.tcs.berReader.BerReader;

public class BerFileListHandler {
	BerReader reader = new BerReader();
	Map<File,BERFileData> map = new HashMap<File,BERFileData>();
	
	public BerFileListHandler() {
		reader.setAutoWrite(false);
	}
	
	public BERFileData getBERData(File file){
		BERFileData data = null;
		if(map.containsKey(file)){
			data = map.get(file);
		}else{
			data = loadBERData(file);
			if(data == null){
				MessageHandler.displayErrorMessage("Unable to read BerFile!!..");
			}
		}
		return data;
		
	}
	private BERFileData loadBERData(File file) {
		BERFileData data = null;
		try {
			data = reader.read(file);
			map.put(file, data);
			
		} catch (Exception e) {
			e.printStackTrace();
			Logger.log(e.getLocalizedMessage());
			Logger.log(e.getMessage());
		} 
		return data;
	}
}
