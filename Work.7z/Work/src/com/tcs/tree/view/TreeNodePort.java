package com.tcs.tree.view;

import com.marconi.fusion.X36.X36PortInformation;
import com.marconi.fusion.base.asn1.ASN1Exception;

public class TreeNodePort implements UserTreeNode{

	private X36PortInformation port;
	
	public TreeNodePort(X36PortInformation port) {
		this.port = port;
	}
	
	@Override
	public String getSyntax() {
		return port.toString();
	}

	@Override
	public String getNormalizedData() {		
		try {
			return port.format();
		} catch (ASN1Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String getName() {
		return "Port:"+port.getPortId().getValue();
	}

	@Override
	public int getId() {
		return port.getPortId().getValue();
	}

	@Override
	public String getSyntaxName() {
		return port.getClass().getSimpleName();
	}
	

	public String toString() {
		return getName();
	}

	@Override
	public String getSpecificInfo() {
		return port.getSpecificPortInformation().toString();
	}
}
