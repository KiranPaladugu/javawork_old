package com.tcs.tree.view;

public interface UserTreeNode {
	public String getSyntax();
	public String getNormalizedData();
	public String getName();
	public int getId();
	public String getSyntaxName();
	public String toString();
	public String getSpecificInfo();
}
