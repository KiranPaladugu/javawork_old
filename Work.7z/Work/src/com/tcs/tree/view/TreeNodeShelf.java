package com.tcs.tree.view;

import com.marconi.fusion.X36.X36ShelfInformation;
import com.marconi.fusion.base.asn1.ASN1Exception;

public class TreeNodeShelf implements UserTreeNode{

	private X36ShelfInformation shelf;
	
	public TreeNodeShelf(X36ShelfInformation shelf) {
		this.shelf = shelf;
	}
	
	@Override
	public String getSyntax() {
		return shelf.toString();
	}

	@Override
	public String getNormalizedData() {		
		try {
			return shelf.format();
		} catch (ASN1Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String getName() {
		return "Shelf:"+shelf.getShelfId().getValue();
	}

	@Override
	public int getId() {
		return shelf.getShelfId().getValue();
	}

	@Override
	public String getSyntaxName() {
		return shelf.getClass().getSimpleName();
	}
	

	public String toString() {
		return getName();
	}

	@Override
	public String getSpecificInfo() {
		return shelf.getShelfType().toString();
	}
}
