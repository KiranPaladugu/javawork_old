package com.tcs.tree.view;

import com.marconi.fusion.X36.X36CardInformation;
import com.marconi.fusion.base.asn1.ASN1Exception;

public class TreeNodeCard implements UserTreeNode{

	private X36CardInformation card;
	
	public TreeNodeCard(X36CardInformation card) {
		this.card = card;
	}
	
	@Override
	public String getSyntax() {
		return card.toString();
	}

	@Override
	public String getNormalizedData() {		
		try {
			return card.format();
		} catch (ASN1Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String getName() {
		return "Card:"+card.getCardId().getValue();
	}

	@Override
	public int getId() {
		return card.getCardId().getValue();
	}

	@Override
	public String getSyntaxName() {
		return card.getClass().getSimpleName();
	}
	

	public String toString() {
		return getName();
	}

	@Override
	public String getSpecificInfo() {
		return card.getCardAdditionalInformation().toString();
	}
}
